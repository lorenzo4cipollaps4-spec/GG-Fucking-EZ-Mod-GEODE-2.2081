# GG EZ Win Sound

Plays the included GG-Fucking-EZ sound when you set a new best or complete a level in a normal run. It plays once per attempt when both events happen together. Practice mode and editor test runs are ignored.
