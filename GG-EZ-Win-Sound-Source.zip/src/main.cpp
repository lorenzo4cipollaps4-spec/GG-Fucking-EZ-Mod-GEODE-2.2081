#include <Geode/Geode.hpp>
#include <Geode/binding/FMODAudioEngine.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include <filesystem>

using namespace geode::prelude;

namespace {
    FMOD::Sound* s_winSound = nullptr;

    void playWinSound() {
        auto* engine = FMODAudioEngine::get();
        auto const soundPath = Mod::get()->getResourcesDir() / "gg-ez.mp3";
        if (!std::filesystem::exists(soundPath)) {
            log::error("GG EZ sound resource is missing.");
            return;
        }

        if (!engine->m_system) {
            log::error("FMOD is not ready to play the GG EZ sound.");
            return;
        }

        // Keep this sound outside the game's effect-channel registry so a level
        // restart can't stop it along with the level's ordinary sound effects.
        // Load it as a sample, not a stream: retries can replay it while the
        // previous playback is still finishing.
        if (!s_winSound) {
            auto const path = soundPath.string();
            auto const createResult = engine->m_system->createSound(
                path.c_str(), FMOD_CREATESAMPLE | FMOD_LOOP_OFF | FMOD_2D, nullptr, &s_winSound
            );
            if (createResult != FMOD_OK) {
                log::error("Could not load the GG EZ sound (FMOD error {}).", static_cast<int>(createResult));
                return;
            }
        }
        if (!s_winSound) {
            log::error("Could not create the GG EZ sound sample.");
            return;
        }

        s_winSound->setMode(FMOD_LOOP_OFF);
        FMOD::Channel* channel = nullptr;
        auto const result = engine->m_system->playSound(s_winSound, nullptr, false, &channel);
        if (result != FMOD_OK || !channel) {
            log::error("Could not play the GG EZ sound (FMOD error {}).", static_cast<int>(result));
            return;
        }

        channel->setMode(FMOD_LOOP_OFF);
        channel->setVolume(engine->m_sfxVolume);
    }
}

class $modify(PlayLayer) {
    struct Fields {
        bool soundPlayedThisAttempt = false;
    };

    void playWinSoundOnce() {
        if (m_fields->soundPlayedThisAttempt || m_isPracticeMode || m_isTestMode) {
            return;
        }

        // The sound is played once even when a new best and a level win happen together.
        m_fields->soundPlayedThisAttempt = true;

        playWinSound();
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        m_fields->soundPlayedThisAttempt = false;
    }

    void resetLevelFromStart() {
        PlayLayer::resetLevelFromStart();
        m_fields->soundPlayedThisAttempt = false;
    }

    void resumeAndRestart(bool fromStart) {
        PlayLayer::resumeAndRestart(fromStart);
        m_fields->soundPlayedThisAttempt = false;
    }

    void fullReset() {
        PlayLayer::fullReset();
        m_fields->soundPlayedThisAttempt = false;
    }

    void showNewBest(bool p0, int p1, int p2, bool p3, bool p4, bool p5) {
        PlayLayer::showNewBest(p0, p1, p2, p3, p4, p5);
        playWinSoundOnce();
    }

    void levelComplete() {
        PlayLayer::levelComplete();
        playWinSoundOnce();
    }
};
