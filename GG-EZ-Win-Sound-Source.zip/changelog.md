# Changelog

## v1.0.3
- Add a mod logo shown in Geode.
- Set the creator name to Roblox7711YT.

## v1.0.2
- Play the sound as a one-shot sample instead of a stream.
- Keep retry playback while resetting the attempt guard only on restart paths.

## v1.0.1
- Keep the sound playing through level resets.
- Reset the once-per-attempt guard across retry paths.

## v1.0.0
- Play the included sound on a new best or level completion.
- Avoid duplicate playback when both occur in the same attempt.
