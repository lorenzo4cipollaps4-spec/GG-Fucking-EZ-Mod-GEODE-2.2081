# GG EZ Win Sound

A Windows Geode mod for Geometry Dash 2.2081. It plays the supplied `GG-Fucking-EZ.mp3` sound when you set a new best or complete a level. If both happen in the same attempt, it plays once. Practice mode and editor test runs are ignored.

## Build

From this Codex workspace, open PowerShell in this folder and run:

```powershell
.\build.ps1
```

The script uses the local Geode CLI, SDK, Clang, CMake, Ninja, and Visual Studio C++ tools. It keeps build files under `work/`, writes the package to `outputs/GG-EZ-Win-Sound.geode`, and installs it to the configured Geometry Dash profile.

To build on another machine, install the Geode CLI, the Geode SDK, CMake, Clang, Ninja, and the Visual Studio C++ build tools, then run `geode build` from the project folder.

To install manually, drop the `.geode` package onto Geometry Dash or copy it into:

```text
%LOCALAPPDATA%\GeometryDash\geode\mods
```

Restart the game and enable **GG EZ Win Sound** in Geode's mod list.

## Sound asset

The supplied sound is packaged at `resources/gg-ez.mp3` and included in the mod through `mod.json`.
