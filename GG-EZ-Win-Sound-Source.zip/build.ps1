$ErrorActionPreference = "Stop"

$projectRoot = $PSScriptRoot
$workspaceRoot = [System.IO.Path]::GetFullPath((Join-Path $projectRoot "..\.."))
$toolRoot = Join-Path $workspaceRoot "work\toolchain"
$buildProject = Join-Path $workspaceRoot "work\gg-ez-build"
$visualStudio = Join-Path $workspaceRoot "work\vsbt"

$geode = Join-Path $toolRoot "geode-cli\geode.exe"
$sdk = Join-Path $toolRoot "geode-sdk"
$cmakeBin = Join-Path $toolRoot "cmake\cmake-4.4.4-windows-x86_64\bin"
$ninjaDir = Join-Path $toolRoot "ninja"
$llvmBin = Join-Path $toolRoot "llvm\LLVM\bin"
$vsDevCmd = Join-Path $visualStudio "Common7\Tools\VsDevCmd.bat"

$requiredPaths = @(
    $geode,
    (Join-Path $sdk "CMakeLists.txt"),
    (Join-Path $cmakeBin "cmake.exe"),
    (Join-Path $ninjaDir "ninja.exe"),
    (Join-Path $llvmBin "clang-cl.exe"),
    $vsDevCmd
)

foreach ($path in $requiredPaths) {
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Required build tool not found: $path"
    }
}

New-Item -ItemType Directory -Path $buildProject -Force | Out-Null
foreach ($file in @("CMakeLists.txt", "mod.json", "README.md", "about.md", "changelog.md", "logo.png")) {
    Copy-Item -LiteralPath (Join-Path $projectRoot $file) -Destination $buildProject -Force
}
foreach ($directory in @("src", "resources")) {
    $destination = Join-Path $buildProject $directory
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    Copy-Item -Path (Join-Path (Join-Path $projectRoot $directory) "*") -Destination $destination -Recurse -Force
}

$vsEnvironment = & $env:ComSpec /d /s /c ('""{0}" -arch=x64 -host_arch=x64 && set"' -f $vsDevCmd)
if ($LASTEXITCODE -ne 0) {
    throw "Could not initialize the Visual Studio C++ environment."
}

foreach ($line in $vsEnvironment) {
    $separator = $line.IndexOf("=")
    if ($separator -gt 0) {
        $name = $line.Substring(0, $separator)
        if ($name -notmatch "^=") {
            Set-Item -Path ("Env:{0}" -f $name) -Value $line.Substring($separator + 1)
        }
    }
}

$env:GEODE_SDK = $sdk
$env:CPM_SOURCE_CACHE = Join-Path $toolRoot "cpm-cache"
$env:CC = Join-Path $llvmBin "clang-cl.exe"
$env:CXX = Join-Path $llvmBin "clang-cl.exe"
$env:PATH = "$llvmBin;$ninjaDir;$cmakeBin;$(Split-Path $geode);$env:PATH"

Push-Location $buildProject
try {
    & $geode build --ninja --config Release
    if ($LASTEXITCODE -ne 0) {
        throw "Geode build failed with exit code $LASTEXITCODE."
    }
}
finally {
    Pop-Location
}

$builtPackage = Join-Path $buildProject "build\ggez.win-sound.geode"
$deliverable = Join-Path (Split-Path $projectRoot -Parent) "GG-EZ-Win-Sound.geode"
if (-not (Test-Path -LiteralPath $builtPackage)) {
    throw "Build succeeded but the expected package was not created: $builtPackage"
}
Copy-Item -LiteralPath $builtPackage -Destination $deliverable -Force
Write-Host "Built package: $deliverable"
